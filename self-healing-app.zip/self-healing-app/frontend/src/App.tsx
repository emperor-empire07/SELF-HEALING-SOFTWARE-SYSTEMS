import { useEffect, useRef, useState } from "react";
import type { FormEvent } from "react";

type Service = { id: string; name: string; health: number; latency: number; status: "ok" | "bug" | "fixing"; message: string };
type Site = { id: number; name: string; url: string; status: "up" | "down" | "checking"; code: number | null; latency: number | null; uptime: number | null };
type Incident = { id: string; name: string; message: string; stage: number };
type Snapshot = {
  services: Service[]; sites: Site[]; incidents: Incident[]; history: number[]; auto: boolean;
  stats: { health: number; bugs: number; fixed: number; mttr: number | null };
};
type Alert = { id: number; level: "bug" | "good" | "warn"; title: string; body: string; time: number };

const STAGES = ["Detect", "Diagnose", "Fix", "Verify"];
const LABEL = { ok: "Healthy", bug: "Bug found", fixing: "Fixing" };

function useLiveData(token: string, onDenied: () => void) {
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [toasts, setToasts] = useState<Alert[]>([]);
  const [online, setOnline] = useState(false);
  const n = useRef(0);

  useEffect(() => {
    let ws: WebSocket, timer: number, stop = false;
    const connect = () => {
      ws = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws?token=${encodeURIComponent(token)}`);
      ws.onopen = () => setOnline(true);
      ws.onclose = (e) => { setOnline(false); if (e.code === 4401) { onDenied(); return; } if (!stop) timer = window.setTimeout(connect, 2000); };
      ws.onmessage = (e) => {
        const m = JSON.parse(e.data);
        if (m.type === "state") return setSnap(m);
        const a: Alert = { ...m, id: ++n.current };
        setAlerts((x) => [a, ...x].slice(0, 30));
        setToasts((x) => [...x, a]);
        window.setTimeout(() => setToasts((x) => x.filter((t) => t.id !== a.id)), a.level === "bug" ? 8000 : 5000);
        if (a.level === "bug" && document.hidden && Notification.permission === "granted") new Notification(a.title, { body: a.body });
      };
    };
    connect();
    return () => { stop = true; clearTimeout(timer); ws?.close(); };
  }, [token]);
  return { snap, alerts, toasts, online };
}

type Past = { name: string; message: string; started: number; seconds: number | null };

function Dashboard({ token, onLogout }: { token: string; onLogout: () => void }) {
  const { snap, alerts, toasts, online } = useLiveData(token, onLogout);
  const auth = { Authorization: `Bearer ${token}` };
  const [past, setPast] = useState<Past[]>([]);
  const [url, setUrl] = useState(""), [nm, setNm] = useState(""), [heal, setHeal] = useState(""), [siteErr, setSiteErr] = useState("");
  const addSite = async (e: FormEvent) => {
    e.preventDefault(); setSiteErr("");
    const r = await fetch("/api/sites", { method: "POST", headers: { ...auth, "Content-Type": "application/json" }, body: JSON.stringify({ url, name: nm, heal_url: heal }) });
    if (r.ok) { setUrl(""); setNm(""); setHeal(""); return; }
    const d = (await r.json().catch(() => ({}))).detail;
    setSiteErr(typeof d === "string" ? d : "Could not add this website. Check the address.");
  };
  const removeSite = (id: number) => fetch(`/api/sites/${id}`, { method: "DELETE", headers: auth });
  const bugCount = snap?.stats.bugs ?? 0, fixedCount = snap?.stats.fixed ?? 0;
  useEffect(() => {
    fetch("/api/incidents", { headers: auth })
      .then((r) => { if (r.status === 401) { onLogout(); throw new Error("auth"); } return r.json(); })
      .then(setPast).catch(() => {});
  }, [bugCount, fixedCount]);
  const [open, setOpen] = useState(false);
  const [seen, setSeen] = useState(0);
  const unread = open ? 0 : alerts.length - seen;
  useEffect(() => { if (open) setSeen(alerts.length); }, [open, alerts.length]);

  const inject = () => {
    fetch("/api/inject", { method: "POST", headers: auth });
    if (Notification.permission === "default") Notification.requestPermission();
  };
  const toggleAuto = (v: boolean) => fetch(`/api/auto/${v}`, { method: "POST", headers: auth });

  if (!snap) return <div className="wrap"><p className="sub">{online ? "Loading…" : "Can’t reach the backend. Start it with: uvicorn main:app --port 8000"}</p></div>;
  const { stats, history } = snap;
  const pts = history.map((v, i) => `${(i * 600) / 59},${140 - (v / 100) * 130}`).join(" ");

  return (
    <div className="wrap">
      <div id="toasts" aria-live="assertive">
        {toasts.map((t) => (
          <div key={t.id} className={`toast ${t.level}`} role={t.level === "bug" ? "alert" : "status"}>
            <b>{t.title}</b><span className="sub">{t.body}</span>
          </div>
        ))}
      </div>
      <header>
        <div><h1>Self-Healing Systems</h1><div className="sub">{online ? "Connected · live" : "Reconnecting…"}</div></div>
        <div className="bar">
          <label><input type="checkbox" checked={snap.auto} onChange={(e) => toggleAuto(e.target.checked)} /> Random bugs</label>
          <button className="primary" onClick={inject}>Inject a bug</button>
          <button onClick={onLogout}>Log out</button>
          <div className="bell">
            <button onClick={() => setOpen(!open)} aria-expanded={open}>Alerts{unread > 0 && <span className="badge">{unread}</span>}</button>
            {open && (
              <div id="drop" role="dialog" aria-label="Alert history">
                {alerts.length === 0 && <div className="sub">No alerts yet.</div>}
                <ul className="log">{alerts.map((a) => <li key={a.id}><time>{new Date(a.time * 1000).toLocaleTimeString()}</time><b>{a.title}</b> – {a.body}</li>)}</ul>
              </div>
            )}
          </div>
        </div>
      </header>

      <section className="stats">
        <Stat v={`${Math.round(stats.health)}%`} l="System health" />
        <Stat v={stats.bugs} l="Bugs detected" />
        <Stat v={stats.fixed} l="Auto-healed" />
        <Stat v={stats.mttr ? `${stats.mttr.toFixed(1)}s` : "–"} l="Avg. time to heal" />
      </section>

      <div className="grid">
        <div>
          <div className="panel"><h2>Websites</h2>
            <form className="add" onSubmit={addSite}>
              <input type="text" placeholder="Website address, for example example.com" value={url} onChange={(e) => setUrl(e.target.value)} required aria-label="Website address" />
              <input type="text" placeholder="Name (optional)" value={nm} onChange={(e) => setNm(e.target.value)} aria-label="Website name" />
              <input type="text" placeholder="Restart link (optional), called when the site goes down" value={heal} onChange={(e) => setHeal(e.target.value)} aria-label="Restart link" />
              {siteErr && <div role="alert" className="err">{siteErr}</div>}
              <button className="primary" type="submit">Add website</button>
            </form>
            {snap.sites.length === 0 && <div className="sub">No websites yet. Add one above and it is checked every 15 seconds.</div>}
            {snap.sites.map((w) => (
              <div className="site" key={w.id}>
                <div><b>{w.name}</b><div className="sub">{w.url}</div></div>
                <span className={`pill ${w.status === "up" ? "s-ok" : w.status === "down" ? "s-bug" : "s-fixing"}`}>{w.status === "up" ? "Up" : w.status === "down" ? "Down" : "Checking"}</span>
                <button onClick={() => removeSite(w.id)} aria-label={`Remove ${w.name}`}>Remove</button>
                <div className="meta">{w.code ? `HTTP ${w.code}` : w.status === "down" ? "No response" : "Waiting for first check"}{w.latency !== null && ` · ${Math.round(w.latency)} ms`}{w.uptime !== null && ` · ${w.uptime.toFixed(1)}% uptime`}</div>
              </div>
            ))}
          </div>
          <div className="panel"><h2>Services</h2>
            {snap.services.map((s) => (
              <div className="svc" key={s.id}>
                <b>{s.name}</b><span className={`pill s-${s.status}`}>{LABEL[s.status]}</span>
                <div className="meter" role="progressbar" aria-valuenow={Math.round(s.health)} aria-valuemin={0} aria-valuemax={100} aria-label={`${s.name} health`}>
                  <i className={`m-${s.status}`} style={{ width: `${s.health}%` }} />
                </div>
                <div className="meta">{Math.round(s.health)}% health · {Math.round(s.latency)} ms{s.message && ` · ${s.message}`}</div>
              </div>
            ))}
          </div>
          <div className="panel"><h2>Health over the last 60 seconds</h2>
            <svg viewBox="0 0 600 150" role="img" aria-label="System health chart" className="chart">
              <g stroke="var(--line)"><line x1="0" y1="10" x2="600" y2="10" /><line x1="0" y1="75" x2="600" y2="75" /><line x1="0" y1="140" x2="600" y2="140" /></g>
              <polyline points={pts} fill="none" strokeWidth="3" strokeLinejoin="round" stroke={stats.health < 80 ? "var(--bug)" : stats.health < 95 ? "var(--fix)" : "var(--accent)"} />
            </svg>
          </div>
        </div>
        <div>
        <div className="panel"><h2>Healing in progress</h2>
          {snap.incidents.length === 0 && <div className="sub">No active problems. Select “Inject a bug” to see a fix run.</div>}
          {snap.incidents.map((i) => (
            <div className="inc" key={i.id}>
              <b>{i.name}</b><div className="sub">{i.message}</div>
              <div className="steps">{STAGES.map((_, k) => <div key={k} className={`step ${k < i.stage ? "done" : k === i.stage ? "active" : ""}`} />)}</div>
              <div className="labels">{STAGES.map((g) => <span key={g}>{g}</span>)}</div>
            </div>
          ))}
        </div>
        <div className="panel"><h2>Incident history</h2>
          {past.length === 0 && <div className="sub">No incidents saved yet.</div>}
          <ul className="log">{past.map((p, k) => <li key={k}><time>{new Date(p.started * 1000).toLocaleString()}</time><b>{p.name}</b> – {p.message} · {p.seconds === null ? "healing…" : `fixed in ${p.seconds.toFixed(1)}s`}</li>)}</ul>
        </div>
        </div>
      </div>
    </div>
  );
}

const Stat = ({ v, l }: { v: string | number; l: string }) => <div className="stat"><div className="num">{v}</div><span>{l}</span></div>;

function Login({ onToken }: { onToken: (t: string) => void }) {
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [err, setErr] = useState("");
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const r = await fetch("/api/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: u, password: p }) });
    if (!r.ok) return setErr("Wrong username or password.");
    onToken((await r.json()).token);
  };
  return (
    <div className="wrap login">
      <h1>Self-Healing Systems</h1>
      <p className="sub">Log in to see live system health.</p>
      <form onSubmit={submit} className="panel">
        <label>Username<input value={u} onChange={(e) => setU(e.target.value)} autoComplete="username" required /></label>
        <label>Password<input type="password" value={p} onChange={(e) => setP(e.target.value)} autoComplete="current-password" required /></label>
        {err && <div role="alert" className="err">{err}</div>}
        <button className="primary" type="submit">Log in</button>
      </form>
    </div>
  );
}

export default function App() {
  const [token, setToken] = useState(() => localStorage.getItem("token") || "");
  const save = (t: string) => { t ? localStorage.setItem("token", t) : localStorage.removeItem("token"); setToken(t); };
  return token ? <Dashboard token={token} onLogout={() => save("")} /> : <Login onToken={save} />;
}
